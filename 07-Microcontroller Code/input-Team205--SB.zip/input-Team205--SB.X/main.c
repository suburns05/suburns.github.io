#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "mcc_generated_files/system/system.h"

// Pin Definitions
#define MOTOR_FWD      LATFbits.LATF4
#define MOTOR_REV      LATFbits.LATF5
#define LED            LATFbits.LATF3

#define BTN_START      PORTDbits.RD1
#define BTN_END        PORTDbits.RD2
#define BTN_RESET      PORTDbits.RD3
#define BTN_DEBUG      PORTEbits.RE1

#define SENSOR_SOUND   PORTAbits.RA2
#define SENSOR_LIGHT   PORTBbits.RB0

// Timing
#define SENSOR_TIMER   500  // 5 seconds
#define BLINK_TIMER    100  // 1 second

// State
typedef enum { STOPPED, FORWARD, REVERSE } motor_state_t;
motor_state_t motor_state = STOPPED;

volatile uint16_t sensor_timer = 0;
volatile uint16_t blink_timer = 0;
volatile uint8_t blink_count = 0;
volatile bool timer_active = false;
volatile bool blink_active = false;

// Simple button state
uint8_t btn_count[4] = {0};
bool btn_prev[4] = {0};
#define BTN_START_IDX 0
#define BTN_END_IDX   1
#define BTN_RESET_IDX 2
#define BTN_DEBUG_IDX 3

// UART
void uart_print(const char* str) {
    if (U1CON1bits.ON != 1) return;
    while (*str) {
        while (!PIR4bits.U1TXIF);
        U1TXB = *str++;
    }
}

void uart_println(const char* str) {
    uart_print(str);
    if (U1CON1bits.ON == 1) {
        while (!PIR4bits.U1TXIF); U1TXB = '\r';
        while (!PIR4bits.U1TXIF); U1TXB = '\n';
    }
}

// Debounce - returns true on new press only
bool btn_pressed(uint8_t idx, bool input) {
    if (input) {
        if (btn_count[idx] < 255) btn_count[idx]++;
        if (btn_count[idx] >= 5 && !btn_prev[idx]) {
            btn_prev[idx] = true;
            return true;
        }
    } else {
        btn_count[idx] = 0;
        btn_prev[idx] = false;
    }
    return false;
}

// Motor control
void motor_stop(void) {
    MOTOR_FWD = 0;
    MOTOR_REV = 0;
    motor_state = STOPPED;
}

void motor_forward(void) {
    MOTOR_FWD = 1;
    MOTOR_REV = 0;
    motor_state = FORWARD;
}

void motor_reverse(void) {
    MOTOR_FWD = 0;
    MOTOR_REV = 1;
    motor_state = REVERSE;
}

// Timer interrupt
void __interrupt(high_priority) timer_isr(void) {
    if (PIR3bits.TMR0IF) {
        PIR3bits.TMR0IF = 0;
        TMR0H = 0xFD;
        TMR0L = 0x8F;
        
        // Sensor timer
        if (timer_active && sensor_timer > 0) {
            sensor_timer--;
            if (sensor_timer == 0) {
                LED = 0;
                timer_active = false;
            }
        }
        
        // Blink sequence
        if (blink_active && blink_timer > 0) {
            blink_timer--;
            if (blink_timer == 0) {
                LED = !LED;
                if (!LED) {
                    blink_count--;
                    if (blink_count == 0) {
                        blink_active = false;
                    } else {
                        blink_timer = BLINK_TIMER;
                    }
                } else {
                    blink_timer = BLINK_TIMER;
                }
            }
        }
    }
}

// Init
void init_hardware(void) {
    SYSTEM_Initialize();
    
    TRISFbits.TRISF4 = 0; TRISFbits.TRISF5 = 0; TRISFbits.TRISF3 = 0;
    TRISDbits.TRISD1 = 1; TRISDbits.TRISD2 = 1; TRISDbits.TRISD3 = 1;
    TRISEbits.TRISE1 = 1; TRISAbits.TRISA2 = 1; TRISBbits.TRISB0 = 1;
    
    ANSELA = 0; ANSELB = 0; ANSELD = 0; ANSELE = 0; ANSELF = 0;
    
    T0CON0 = 0x90; T0CON1 = 0x48;
    TMR0H = 0xFD; TMR0L = 0x8F;
    PIE3bits.TMR0IE = 1;
    
    INTCON0bits.IPEN = 1;
    INTCON0bits.GIEH = 1;
    INTCON0bits.GIEL = 1;
    
    motor_stop();
    LED = 0;
}

// Main
int main(void) {
    init_hardware();
    uart_println("=== System Ready ===");
    
    bool prev_light = false;
    bool sound_triggered = false;
    
    while (1) {
        bool light = SENSOR_LIGHT;
        bool sound = SENSOR_SOUND;
        
        // Log only light changes (sound is too noisy)
        if (light && !prev_light) {
            uart_println("[SENSOR] Light ON");
        } else if (!light && prev_light) {
            uart_println("[SENSOR] Light OFF");
        }
        prev_light = light;
        
        // Sound trigger detection (latch until used)
        if (sound && light) {
            sound_triggered = true;
        }
        
        // === DEBUG BUTTON (highest priority) ===
        if (btn_pressed(BTN_DEBUG_IDX, BTN_DEBUG) && !blink_active) {
            uart_println("[DEBUG] System check");
            
            bool issue = false;
            if (motor_state != STOPPED) {
                uart_println("  Motor was running - stopped");
                motor_stop();
                issue = true;
            }
            if (LED || timer_active) {
                uart_println("  LED/Timer active - cleared");
                LED = 0;
                timer_active = false;
                sensor_timer = 0;
                issue = true;
            }
            
            if (!issue) uart_println("  All normal");
            
            uart_println("  2x flash");
            LED = 1;
            blink_count = 2;
            blink_timer = BLINK_TIMER;
            blink_active = true;
        }
        
        // === SOUND + LIGHT TRIGGER ===
        if (sound_triggered && light) {
            motor_stop();
            if (!timer_active && !blink_active) {
                uart_println("[TRIGGER] Sound+Light - LED 5s");
                LED = 1;
                sensor_timer = SENSOR_TIMER;
                timer_active = true;
            }
            sound_triggered = false;
        }
        
        // === RESET BUTTON ===
        if (btn_pressed(BTN_RESET_IDX, BTN_RESET)) {
            if (motor_state != STOPPED) {
                uart_println("[RESET] Motor stopped");
                motor_stop();
            }
        }
        
        // === MOTOR CONTROL (only if light on and no timers) ===
        if (!timer_active && !blink_active && light) {
            if (btn_pressed(BTN_START_IDX, BTN_START)) {
                uart_println("[START] Forward");
                motor_forward();
            }
            
            if (btn_pressed(BTN_END_IDX, BTN_END)) {
                uart_println("[END] Reverse");
                motor_reverse();
            }
        }
        
        // === SAFETY: Stop if light lost ===
        if (!light && motor_state != STOPPED) {
            uart_println("[SAFETY] Light lost - stopped");
            motor_stop();
        }
        
        __delay_ms(10);
    }
    
    return 0;
}